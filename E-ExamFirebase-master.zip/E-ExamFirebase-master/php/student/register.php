<?php
require ('../../php/header.php');
require ('../../realtime.php');
@$levels = SelectLevels('Levels');
