<?php
if(isset($_GET['level']) and isset($_GET['subject'])){
  //  header('location:examResult.php?level='.$_GET['level'].'&subject='.$_GET['subject'].' ');
}